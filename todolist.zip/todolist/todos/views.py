from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Todo
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
import time
from datetime import datetime

# Create your views here.

@login_required
def homepage(request):
    now_timestamp = time.time()
    offset = datetime.fromtimestamp(now_timestamp) - datetime.utcfromtimestamp(now_timestamp)
    loginTime = request.user.last_login + offset
    request.user.first_name = request.user_agent.browser.family
    request.user.last_name = request.user_agent.os.family
    request.user.save()
    context = {
        'todos': Todo.objects.all().filter(author=request.user, complete=False),
        'completedTodos': Todo.objects.all().filter(author=request.user, complete=True),
        'numIncomplete': len(Todo.objects.all().filter(author=request.user, complete=False)),
        'lastLogin': datetime.now(),
        'loginBrowser': request.user_agent.browser.family,
        'loginDevice': request.user_agent.os.family,
    }
    return render(request, 'todos/homepage.html', context)

class TodoList(ListView):
    model = Todo
    context_object_name = 'tasks'
    template_name = 'todos/homepage.html'

def addTodo(request):
    newTodo = Todo(description= request.POST['content'], author= request.user)
    newTodo.save()
    return redirect('todos-homepage')

def deleteTodo(request, id):
    temp = get_object_or_404(Todo, id = id)
    temp.delete()
    return redirect('todos-homepage')

class TodoUpdate(UpdateView):
    model = Todo
    fields = {'complete', 'description'}
    success_url = reverse_lazy('todos-homepage')




