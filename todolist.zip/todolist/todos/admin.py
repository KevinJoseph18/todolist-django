from django.contrib import admin
from .models import Todo
from django.contrib.auth.models import Group

# Register your models here.
class TodoA(admin.ModelAdmin):
    list_display = ('description', 'complete', 'author')
    list_filter = ('author', 'complete')

admin.site.unregister(Group)
admin.site.register(Todo, TodoA)
admin.site.site_header = "TodoList Admin"
