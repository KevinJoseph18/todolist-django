from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from datetime import datetime

# Create your models here.
class Todo(models.Model):
    description = models.CharField(max_length = 200)
    complete = models.BooleanField(default = False)
    date_posted = models.DateTimeField(default = timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.description

    def elapsedTime(self):
        return (datetime.now(timezone.utc) - self.date_posted).days
    class Meta:
        ordering = ['date_posted']