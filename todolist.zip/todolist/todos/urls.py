from django.urls import path
from . import views
from .views import TodoList, TodoUpdate

urlpatterns = [
    path('', views.homepage, name='todos-homepage'),
    path('addTodo/', views.addTodo, name='add-todo'),
    path('editTodo/<int:pk>', TodoUpdate.as_view(), name='edit-todo'),
    path('<id>/deleteTodo/', views.deleteTodo, name='delete-todo'),
]