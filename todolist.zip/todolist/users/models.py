from django.db import models
from django.contrib import admin
from django.contrib.auth.models import User
from django.db import models
from todos.models import Todo
import string

# Create your models here.
class UserA(admin.ModelAdmin):
    list_display = ('username', 'is_staff', 'tasks_completed', 'total_tasks', 'percent_complete', 'login_device', 'last_login')

    def total_tasks(self, id):
        return len(Todo.objects.all().filter(author=id))

    #Uses first_name and last_name as dummy variables
    def login_device(self, id):
        if id.first_name == "":
            return ""
        return id.first_name + " on " + id.last_name

    def tasks_completed(self, id):
        return len(Todo.objects.all().filter(author=id, complete=True))

    def percent_complete(self, id):
        complete = float(len(Todo.objects.all().filter(complete=True, author = id)))
        total = float(len(Todo.objects.all().filter(author=id)))
        if total == 0:
            return str(0) + "%"
        return str(round((complete/total * 100), 2)) + "%"