Kevin Joseph

This is a todolist application I built using python Django web framework. 
Contains all basic CRUD functionality, and allows for user creation and 
handles authorization and authentication

Instructions to run todolist app on local machine:
(options)

1: using the included virtual environment

Navigate to todolist directory in cmd

Scripts\activate
python manage.py runserver

2: install requirements onto machine
(if venv does not work)

Navigate to todolist directory in cmd

pip install -r requirements.txt
python manage.py runserver

Either of these two methods should start the app running on localhost:8000